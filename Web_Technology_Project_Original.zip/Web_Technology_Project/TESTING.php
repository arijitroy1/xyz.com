<?php
	require("TESTING1.php");
	echo "testing main";
?>